package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ChargeCalculation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Yadea EV Charge", appName)
  }

  @Test
  fun `test yadea gt80 charge calculation`() {
    val calc = ChargeCalculation(
      batteryCapacityAh = 50.0f,
      chargerCurrentA = 6.0f,
      voltageV = 72.0f,
      currentPercent = 20,
      targetPercent = 80,
      efficiencyPercent = 90.0f,
      electricityRate = 4.5f
    )

    // 20% to 80% = 60% of 50Ah = 30Ah
    assertEquals(30.0f, calc.capacityNeededAh, 0.01f)
    // 30Ah / 6A = 5.0 hours theoretical
    assertEquals(5.0f, calc.theoreticalHours, 0.01f)
    // 5.0 / 0.9 = 5.555h = 333 minutes = 5 hours 33 minutes
    assertEquals(5, calc.hours)
    assertEquals(33, calc.minutes)
    // Energy: (30 * 72 / 1000) / 0.9 = 2.4 kWh
    assertEquals(2.4f, calc.energyKwh, 0.01f)
    // Cost: 2.4 * 4.5 = 10.8 THB
    assertEquals(10.8f, calc.costThb, 0.01f)
  }
}
