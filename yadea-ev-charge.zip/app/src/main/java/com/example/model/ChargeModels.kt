package com.example.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChargeCalculation(
    val batteryCapacityAh: Float = 50.0f,    // Yadea GT80 battery capacity (50Ah)
    val chargerCurrentA: Float = 6.0f,       // Charger output current (6A)
    val voltageV: Float = 72.0f,              // Nominal battery voltage (72V)
    val currentPercent: Int = 20,             // Current battery percentage
    val targetPercent: Int = 80,              // Target battery percentage
    val efficiencyPercent: Float = 90.0f,     // Charging efficiency (approx 90%)
    val electricityRate: Float = 4.5f         // Electricity rate per kWh in THB
) {
    val percentDelta: Int
        get() = (targetPercent - currentPercent).coerceAtLeast(0)

    val capacityNeededAh: Float
        get() = percentDelta * batteryCapacityAh / 100.0f

    val theoreticalHours: Float
        get() = if (chargerCurrentA > 0f) capacityNeededAh / chargerCurrentA else 0f

    val realisticHours: Float
        get() = if (efficiencyPercent > 0f) theoreticalHours / (efficiencyPercent / 100.0f) else theoreticalHours

    val totalMinutes: Int
        get() = (realisticHours * 60).toInt()

    val hours: Int
        get() = totalMinutes / 60

    val minutes: Int
        get() = totalMinutes % 60

    val energyKwh: Float
        get() = if (efficiencyPercent > 0f) {
            (capacityNeededAh * voltageV / 1000.0f) / (efficiencyPercent / 100.0f)
        } else {
            capacityNeededAh * voltageV / 1000.0f
        }

    val costThb: Float
        get() = energyKwh * electricityRate

    fun getEstimatedCompletionTime(startTimeMillis: Long = System.currentTimeMillis()): Long {
        return startTimeMillis + (totalMinutes * 60 * 1000L)
    }

    fun formatDuration(): String {
        return when {
            hours > 0 && minutes > 0 -> "$hours ชม. $minutes นาที"
            hours > 0 -> "$hours ชั่วโมง"
            else -> "$minutes นาที"
        }
    }

    fun formatEstimatedEndTime(startTimeMillis: Long = System.currentTimeMillis()): String {
        val endTime = getEstimatedCompletionTime(startTimeMillis)
        val sdf = SimpleDateFormat("HH:mm น.", Locale.forLanguageTag("th-TH"))
        return sdf.format(Date(endTime))
    }
}

data class ChargeHistoryItem(
    val id: Long = System.currentTimeMillis(),
    val timestamp: Long = System.currentTimeMillis(),
    val startPercent: Int,
    val targetPercent: Int,
    val durationMinutes: Int,
    val energyKwh: Float,
    val costThb: Float
) {
    fun formattedDate(): String {
        val sdf = SimpleDateFormat("d MMM yyyy HH:mm", Locale.forLanguageTag("th-TH"))
        return sdf.format(Date(timestamp))
    }

    fun formattedDuration(): String {
        val h = durationMinutes / 60
        val m = durationMinutes % 60
        return when {
            h > 0 && m > 0 -> "$h ชม. $m นาที"
            h > 0 -> "$h ชม."
            else -> "$m นาที"
        }
    }
}
