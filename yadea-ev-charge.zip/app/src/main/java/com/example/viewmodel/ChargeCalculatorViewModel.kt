package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ChargeRepository
import com.example.model.ChargeCalculation
import com.example.model.ChargeHistoryItem
import com.example.notification.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ChargeUiState(
    val calculation: ChargeCalculation = ChargeCalculation(),
    val isChargingActive: Boolean = false,
    val sessionStartTime: Long = 0L,
    val sessionEndTime: Long = 0L,
    val remainingMillis: Long = 0L,
    val currentSimulatedPercent: Int = 20,
    val historyList: List<ChargeHistoryItem> = emptyList(),
    val showSettingsDialog: Boolean = false,
    val showSmartPlugDialog: Boolean = false,
    val toastMessage: String? = null
)

class ChargeCalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ChargeRepository(application)
    private val _uiState = MutableStateFlow(ChargeUiState())
    val uiState: StateFlow<ChargeUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    init {
        NotificationHelper.createNotificationChannels(application)
        loadFromRepository()
        checkActiveSession()
    }

    private fun loadFromRepository() {
        val calc = ChargeCalculation(
            batteryCapacityAh = repository.batteryCapacityAh,
            chargerCurrentA = repository.chargerCurrentA,
            voltageV = repository.voltageV,
            currentPercent = repository.currentPercent,
            targetPercent = repository.targetPercent,
            efficiencyPercent = repository.efficiencyPercent,
            electricityRate = repository.electricityRate
        )
        _uiState.update {
            it.copy(
                calculation = calc,
                historyList = repository.getHistory()
            )
        }
    }

    private fun checkActiveSession() {
        if (repository.isChargingActive) {
            val now = System.currentTimeMillis()
            val endTime = repository.sessionEndTime
            if (now < endTime) {
                _uiState.update {
                    it.copy(
                        isChargingActive = true,
                        sessionStartTime = repository.sessionStartTime,
                        sessionEndTime = endTime,
                        remainingMillis = endTime - now
                    )
                }
                startCountdownLoop()
            } else {
                repository.isChargingActive = false
                _uiState.update { it.copy(isChargingActive = false) }
            }
        }
    }

    fun setCurrentPercent(percent: Int) {
        val clamped = percent.coerceIn(0, 100)
        val currentTarget = _uiState.value.calculation.targetPercent
        val newTarget = if (clamped >= currentTarget) (clamped + 10).coerceAtMost(100) else currentTarget

        _uiState.update { state ->
            val updated = state.calculation.copy(
                currentPercent = clamped,
                targetPercent = newTarget
            )
            repository.currentPercent = clamped
            repository.targetPercent = newTarget
            state.copy(calculation = updated)
        }
    }

    fun setTargetPercent(percent: Int) {
        val clamped = percent.coerceIn(_uiState.value.calculation.currentPercent, 100)
        _uiState.update { state ->
            val updated = state.calculation.copy(targetPercent = clamped)
            repository.targetPercent = clamped
            state.copy(calculation = updated)
        }
    }

    fun applyPresetTarget(targetPct: Int) {
        val current = _uiState.value.calculation.currentPercent
        val effectiveTarget = if (targetPct <= current) (current + 10).coerceAtMost(100) else targetPct
        setTargetPercent(effectiveTarget)
    }

    fun updateSpecs(
        capacityAh: Float,
        chargerAmps: Float,
        voltage: Float,
        efficiency: Float,
        electricityRate: Float
    ) {
        repository.batteryCapacityAh = capacityAh
        repository.chargerCurrentA = chargerAmps
        repository.voltageV = voltage
        repository.efficiencyPercent = efficiency
        repository.electricityRate = electricityRate

        _uiState.update { state ->
            val updated = state.calculation.copy(
                batteryCapacityAh = capacityAh,
                chargerCurrentA = chargerAmps,
                voltageV = voltage,
                efficiencyPercent = efficiency,
                electricityRate = electricityRate
            )
            state.copy(calculation = updated, showSettingsDialog = false)
        }
    }

    fun resetToYadeaGt80Default() {
        updateSpecs(
            capacityAh = 50.0f,
            chargerAmps = 6.0f,
            voltage = 72.0f,
            efficiency = 90.0f,
            electricityRate = 4.5f
        )
    }

    fun startChargingSession(context: Context) {
        val calc = _uiState.value.calculation
        val now = System.currentTimeMillis()
        val durationMillis = calc.totalMinutes * 60 * 1000L
        val endTime = now + durationMillis

        repository.isChargingActive = true
        repository.sessionStartTime = now
        repository.sessionEndTime = endTime
        repository.sessionStartPct = calc.currentPercent
        repository.sessionTargetPct = calc.targetPercent

        // Schedule exact alarm for when target is reached
        NotificationHelper.scheduleChargeAlarm(
            context = context,
            triggerTimeMillis = endTime,
            targetPercent = calc.targetPercent,
            hours = calc.hours,
            minutes = calc.minutes,
            energyKwh = calc.energyKwh,
            cost = calc.costThb
        )

        // Show status notification
        NotificationHelper.showChargingStatusNotification(
            context = context,
            currentPercent = calc.currentPercent,
            targetPercent = calc.targetPercent,
            formattedRemaining = calc.formatDuration(),
            targetTimeFormatted = calc.formatEstimatedEndTime(now)
        )

        // Save history item
        val historyItem = ChargeHistoryItem(
            id = now,
            timestamp = now,
            startPercent = calc.currentPercent,
            targetPercent = calc.targetPercent,
            durationMinutes = calc.totalMinutes,
            energyKwh = calc.energyKwh,
            costThb = calc.costThb
        )
        repository.addHistoryItem(historyItem)

        _uiState.update {
            it.copy(
                isChargingActive = true,
                sessionStartTime = now,
                sessionEndTime = endTime,
                remainingMillis = durationMillis,
                historyList = repository.getHistory(),
                toastMessage = "เริ่มจับเวลาและตั้งแจ้งเตือนแล้ว! ระบบจะเตือนเมื่อถึง ${calc.targetPercent}%"
            )
        }

        startCountdownLoop()
    }

    fun stopChargingSession(context: Context) {
        timerJob?.cancel()
        timerJob = null

        repository.isChargingActive = false
        NotificationHelper.cancelChargeAlarm(context)

        _uiState.update {
            it.copy(
                isChargingActive = false,
                remainingMillis = 0L,
                toastMessage = "หยุดการชาร์จและยกเลิกการแจ้งเตือนแล้ว"
            )
        }
    }

    fun testAlarmNotification(context: Context) {
        val calc = _uiState.value.calculation
        NotificationHelper.showChargeCompleteNotification(
            context = context,
            targetPercent = calc.targetPercent,
            hours = calc.hours,
            minutes = calc.minutes,
            energyKwh = calc.energyKwh,
            cost = calc.costThb
        )
        _uiState.update {
            it.copy(toastMessage = "ส่งการแจ้งเตือนทดสอบแล้ว! ตรวจสอบแถบแจ้งเตือนด้านบน")
        }
    }

    private fun startCountdownLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                val now = System.currentTimeMillis()
                val endTime = _uiState.value.sessionEndTime
                val remaining = (endTime - now).coerceAtLeast(0L)

                val startPct = repository.sessionStartPct
                val targetPct = repository.sessionTargetPct
                val totalDuration = (endTime - _uiState.value.sessionStartTime).coerceAtLeast(1L)
                val elapsed = (now - _uiState.value.sessionStartTime).coerceAtLeast(0L)
                val progress = (elapsed.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
                val simulatedPct = (startPct + (progress * (targetPct - startPct))).toInt()

                _uiState.update {
                    it.copy(
                        remainingMillis = remaining,
                        currentSimulatedPercent = simulatedPct
                    )
                }

                if (remaining <= 0L) {
                    repository.isChargingActive = false
                    _uiState.update { it.copy(isChargingActive = false) }
                    break
                }
                delay(1000L)
            }
        }
    }

    fun openSettingsDialog(show: Boolean) {
        _uiState.update { it.copy(showSettingsDialog = show) }
    }

    fun openSmartPlugDialog(show: Boolean) {
        _uiState.update { it.copy(showSmartPlugDialog = show) }
    }

    fun clearHistory() {
        repository.clearHistory()
        _uiState.update { it.copy(historyList = emptyList()) }
    }

    fun clearToastMessage() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
