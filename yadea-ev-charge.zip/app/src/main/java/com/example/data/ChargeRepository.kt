package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.ChargeHistoryItem
import org.json.JSONArray
import org.json.JSONObject

class ChargeRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("yadea_charge_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CAPACITY = "key_capacity"
        private const val KEY_CHARGER_A = "key_charger_a"
        private const val KEY_VOLTAGE = "key_voltage"
        private const val KEY_ELECTRICITY_RATE = "key_electricity_rate"
        private const val KEY_EFFICIENCY = "key_efficiency"
        private const val KEY_CURRENT_PERCENT = "key_current_percent"
        private const val KEY_TARGET_PERCENT = "key_target_percent"
        private const val KEY_IS_CHARGING = "is_charging_active"
        private const val KEY_START_TIME = "key_start_time"
        private const val KEY_END_TIME = "key_end_time"
        private const val KEY_SESSION_START_PCT = "key_session_start_pct"
        private const val KEY_SESSION_TARGET_PCT = "key_session_target_pct"
        private const val KEY_HISTORY = "key_charge_history"
    }

    var batteryCapacityAh: Float
        get() = prefs.getFloat(KEY_CAPACITY, 50.0f)
        set(value) = prefs.edit().putFloat(KEY_CAPACITY, value).apply()

    var chargerCurrentA: Float
        get() = prefs.getFloat(KEY_CHARGER_A, 6.0f)
        set(value) = prefs.edit().putFloat(KEY_CHARGER_A, value).apply()

    var voltageV: Float
        get() = prefs.getFloat(KEY_VOLTAGE, 72.0f)
        set(value) = prefs.edit().putFloat(KEY_VOLTAGE, value).apply()

    var electricityRate: Float
        get() = prefs.getFloat(KEY_ELECTRICITY_RATE, 4.5f)
        set(value) = prefs.edit().putFloat(KEY_ELECTRICITY_RATE, value).apply()

    var efficiencyPercent: Float
        get() = prefs.getFloat(KEY_EFFICIENCY, 90.0f)
        set(value) = prefs.edit().putFloat(KEY_EFFICIENCY, value).apply()

    var currentPercent: Int
        get() = prefs.getInt(KEY_CURRENT_PERCENT, 20)
        set(value) = prefs.edit().putInt(KEY_CURRENT_PERCENT, value).apply()

    var targetPercent: Int
        get() = prefs.getInt(KEY_TARGET_PERCENT, 80)
        set(value) = prefs.edit().putInt(KEY_TARGET_PERCENT, value).apply()

    var isChargingActive: Boolean
        get() = prefs.getBoolean(KEY_IS_CHARGING, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_CHARGING, value).apply()

    var sessionStartTime: Long
        get() = prefs.getLong(KEY_START_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_START_TIME, value).apply()

    var sessionEndTime: Long
        get() = prefs.getLong(KEY_END_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_END_TIME, value).apply()

    var sessionStartPct: Int
        get() = prefs.getInt(KEY_SESSION_START_PCT, 20)
        set(value) = prefs.edit().putInt(KEY_SESSION_START_PCT, value).apply()

    var sessionTargetPct: Int
        get() = prefs.getInt(KEY_SESSION_TARGET_PCT, 80)
        set(value) = prefs.edit().putInt(KEY_SESSION_TARGET_PCT, value).apply()

    fun getHistory(): List<ChargeHistoryItem> {
        val jsonStr = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        val list = mutableListOf<ChargeHistoryItem>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    ChargeHistoryItem(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        startPercent = obj.optInt("startPercent", 20),
                        targetPercent = obj.optInt("targetPercent", 80),
                        durationMinutes = obj.optInt("durationMinutes", 0),
                        energyKwh = obj.optDouble("energyKwh", 0.0).toFloat(),
                        costThb = obj.optDouble("costThb", 0.0).toFloat()
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun addHistoryItem(item: ChargeHistoryItem) {
        val current = getHistory().toMutableList()
        current.add(0, item)
        // Keep max 20 items
        val trimmed = if (current.size > 20) current.take(20) else current
        try {
            val jsonArray = JSONArray()
            for (history in trimmed) {
                val obj = JSONObject().apply {
                    put("id", history.id)
                    put("timestamp", history.timestamp)
                    put("startPercent", history.startPercent)
                    put("targetPercent", history.targetPercent)
                    put("durationMinutes", history.durationMinutes)
                    put("energyKwh", history.energyKwh.toDouble())
                    put("costThb", history.costThb.toDouble())
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY, jsonArray.toString()).apply()
        } catch (_: Exception) {
        }
    }

    fun clearHistory() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }
}
