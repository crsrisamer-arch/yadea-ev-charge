package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// EV Electric Motorcycle Theme Colors
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00838F)
val ElectricEmerald = Color(0xFF00E676)
val ElectricAmber = Color(0xFFFFD166)
val ElectricBlue = Color(0xFF00B4D8)

val DarkBackground = Color(0xFF0A0E1A)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F293D)
val DarkOutline = Color(0xFF2E3D5C)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOutline = Color(0xFFCBD5E1)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightPrimary = Color(0xFF0284C7)
val LightSecondary = Color(0xFF059669)
