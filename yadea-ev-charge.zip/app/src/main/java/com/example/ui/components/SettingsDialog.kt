package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.ChargeCalculation

@Composable
fun SettingsDialog(
    calculation: ChargeCalculation,
    onSave: (capacity: Float, amps: Float, voltage: Float, efficiency: Float, rate: Float) -> Unit,
    onResetDefaults: () -> Unit,
    onDismiss: () -> Unit
) {
    var capacityText by remember { mutableStateOf(calculation.batteryCapacityAh.toString()) }
    var ampsText by remember { mutableStateOf(calculation.chargerCurrentA.toString()) }
    var voltageText by remember { mutableStateOf(calculation.voltageV.toString()) }
    var efficiencyText by remember { mutableStateOf(calculation.efficiencyPercent.toString()) }
    var rateText by remember { mutableStateOf(calculation.electricityRate.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "ตั้งค่าสเปกมอเตอร์ไซค์และไฟ",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = capacityText,
                    onValueChange = { capacityText = it },
                    label = { Text("ความจุแบตเตอรี่ (Ah)") },
                    supportingText = { Text("ค่าเดิม Yadea GT80: 50 Ah") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = ampsText,
                    onValueChange = { ampsText = it },
                    label = { Text("กระแสไฟเครื่องชาร์จ (A - แอมป์)") },
                    supportingText = { Text("ค่าเดิมเครื่องชาร์จ GT80: 6.0 A") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = voltageText,
                    onValueChange = { voltageText = it },
                    label = { Text("แรงดันไฟฟ้าของระบบ (V - โวลต์)") },
                    supportingText = { Text("เช่น 72V หรือ 60V") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = efficiencyText,
                    onValueChange = { efficiencyText = it },
                    label = { Text("ประสิทธิภาพการชาร์จ (%)") },
                    supportingText = { Text("ประมาณ 88-92% (รวมสูญเสียความร้อนและช่วง CV)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = rateText,
                    onValueChange = { rateText = it },
                    label = { Text("ค่าไฟฟ้าต่อหน่วย (บาท / kWh)") },
                    supportingText = { Text("ค่าไฟเฉลี่ยประเทศไทย ~4.50 บาท") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = {
                        capacityText = "50.0"
                        ampsText = "6.0"
                        voltageText = "72.0"
                        efficiencyText = "90.0"
                        rateText = "4.5"
                        onResetDefaults()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    androidx.compose.material3.Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.padding(start = 6.dp))
                    Text("คืนค่าเดิม Yadea GT80 (50Ah, 6A)")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cap = capacityText.toFloatOrNull() ?: 50.0f
                    val amp = ampsText.toFloatOrNull() ?: 6.0f
                    val volt = voltageText.toFloatOrNull() ?: 72.0f
                    val eff = efficiencyText.toFloatOrNull() ?: 90.0f
                    val rate = rateText.toFloatOrNull() ?: 4.5f
                    onSave(cap, amp, volt, eff, rate)
                },
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("บันทึก")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("ยกเลิก")
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
