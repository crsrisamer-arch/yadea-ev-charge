package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricEmerald

@Composable
fun BatteryVisualizer(
    currentPercent: Int,
    targetPercent: Int,
    capacityAh: Float,
    isCharging: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "charging_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val deltaPercent = (targetPercent - currentPercent).coerceAtLeast(0)
    val deltaAh = deltaPercent * capacityAh / 100f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Battery header stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isCharging) ElectricEmerald else ElectricCyan)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isCharging) "กำลังชาร์จไฟ..." else "จำลองระดับแบตเตอรี่",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Delta Pill
            val formattedAh = "%.1f".format(java.util.Locale.US, deltaAh)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(ElectricCyan.copy(alpha = 0.15f))
                    .border(1.dp, ElectricCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "+$deltaPercent% (+$formattedAh Ah)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Graphical Battery Gauge Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("battery_gauge_canvas")
            ) {
                val batteryTerminalWidth = 10.dp.toPx()
                val batteryTerminalHeight = 22.dp.toPx()
                val corner = CornerRadius(14.dp.toPx(), 14.dp.toPx())

                val bodyWidth = size.width - batteryTerminalWidth - 6.dp.toPx()
                val bodyHeight = size.height
                val bodyOffset = Offset(0f, 0f)

                // Battery Body Border / Background
                drawRoundRect(
                    color = Color(0xFF1E293B).copy(alpha = 0.8f),
                    topLeft = bodyOffset,
                    size = Size(bodyWidth, bodyHeight),
                    cornerRadius = corner
                )
                drawRoundRect(
                    color = Color(0xFF334155),
                    topLeft = bodyOffset,
                    size = Size(bodyWidth, bodyHeight),
                    cornerRadius = corner,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Battery Terminal Notch on right
                val terminalLeft = bodyWidth + 2.dp.toPx()
                val terminalTop = (bodyHeight - batteryTerminalHeight) / 2f
                drawRoundRect(
                    color = Color(0xFF475569),
                    topLeft = Offset(terminalLeft, terminalTop),
                    size = Size(batteryTerminalWidth, batteryTerminalHeight),
                    cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                )

                // Available internal padding
                val innerPad = 4.dp.toPx()
                val maxInnerWidth = bodyWidth - (innerPad * 2)
                val innerHeight = bodyHeight - (innerPad * 2)
                val innerTop = innerPad

                // Target Level Fill (Layer underneath, previewing target % with glowing cyan)
                val targetFillWidth = (maxInnerWidth * (targetPercent / 100f)).coerceIn(0f, maxInnerWidth)
                val targetBrush = Brush.horizontalGradient(
                    colors = listOf(
                        ElectricCyan.copy(alpha = if (isCharging) pulseAlpha * 0.4f else 0.35f),
                        ElectricCyan.copy(alpha = if (isCharging) pulseAlpha * 0.7f else 0.5f)
                    )
                )

                if (targetFillWidth > 0f) {
                    drawRoundRect(
                        brush = targetBrush,
                        topLeft = Offset(innerPad, innerTop),
                        size = Size(targetFillWidth, innerHeight),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )

                    // Dashed line at target position
                    drawLine(
                        color = ElectricCyan,
                        start = Offset(innerPad + targetFillWidth, innerTop),
                        end = Offset(innerPad + targetFillWidth, innerTop + innerHeight),
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
                    )
                }

                // Current Level Fill (Layer on top, solid rich gradient)
                val currentFillWidth = (maxInnerWidth * (currentPercent / 100f)).coerceIn(0f, maxInnerWidth)
                val currentColor1 = when {
                    currentPercent < 20 -> Color(0xFFEF4444)
                    currentPercent < 50 -> ElectricAmber
                    else -> ElectricEmerald
                }
                val currentColor2 = when {
                    currentPercent < 20 -> Color(0xFFDC2626)
                    currentPercent < 50 -> Color(0xFFF59E0B)
                    else -> Color(0xFF10B981)
                }

                if (currentFillWidth > 0f) {
                    drawRoundRect(
                        brush = Brush.horizontalGradient(listOf(currentColor1, currentColor2)),
                        topLeft = Offset(innerPad, innerTop),
                        size = Size(currentFillWidth, innerHeight),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )
                }
            }

            // Central Bolt & Info Overlay
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Battery Status",
                    tint = if (isCharging) ElectricCyan else Color.White,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$currentPercent% ➔ $targetPercent%",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Legend row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                currentPercent < 20 -> Color(0xFFEF4444)
                                currentPercent < 50 -> ElectricAmber
                                else -> ElectricEmerald
                            }
                        )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "ปัจจุบัน: $currentPercent%",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(ElectricCyan)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "เป้าหมาย: $targetPercent%",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun BatterySliderControls(
    currentPercent: Int,
    targetPercent: Int,
    onCurrentPercentChange: (Int) -> Unit,
    onTargetPercentChange: (Int) -> Unit,
    onPresetSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        // Current Percent Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "1. แบตเตอรี่ปัจจุบัน (Current)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$currentPercent%",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = when {
                    currentPercent < 20 -> Color(0xFFEF4444)
                    currentPercent < 50 -> ElectricAmber
                    else -> ElectricEmerald
                }
            )
        }

        androidx.compose.material3.Slider(
            value = currentPercent.toFloat(),
            onValueChange = { onCurrentPercentChange(it.toInt()) },
            valueRange = 0f..100f,
            steps = 99,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("current_percent_slider")
        )

        // Quick Current Pct Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(10, 20, 30, 50).forEach { pct ->
                val isSelected = currentPercent == pct
                androidx.compose.material3.OutlinedButton(
                    onClick = { onCurrentPercentChange(pct) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp)
                ) {
                    Text(
                        text = "$pct%",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Target Percent Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "2. ต้องการชาร์จไปถึง (Target)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (targetPercent == 80) "✨ แนะนำ 80% เพื่อถนอมอายุแบตเตอรี่" else "กำหนดเป้าหมาย",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (targetPercent == 80) ElectricEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "$targetPercent%",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = ElectricCyan
            )
        }

        androidx.compose.material3.Slider(
            value = targetPercent.toFloat(),
            onValueChange = { onTargetPercentChange(it.toInt()) },
            valueRange = currentPercent.toFloat().coerceAtMost(100f)..100f,
            steps = ((100 - currentPercent) - 1).coerceAtLeast(0),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("target_percent_slider")
        )

        // Presets Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val presets = listOf(
                Pair(80, "80% (ถนอมแบต)"),
                Pair(90, "90% (เดินทาง)"),
                Pair(100, "100% (เต็ม)")
            )

            presets.forEach { (pct, label) ->
                val isSelected = targetPercent == pct
                androidx.compose.material3.FilterChip(
                    selected = isSelected,
                    onClick = { onPresetSelected(pct) },
                    label = {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }
    }
}
