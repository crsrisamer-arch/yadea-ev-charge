package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.receiver.ChargeAlarmReceiver

object NotificationHelper {

    const val CHANNEL_ALARM_ID = "yadea_charge_complete_channel"
    const val CHANNEL_STATUS_ID = "yadea_charge_status_channel"

    const val NOTIFICATION_ALARM_ID = 1001
    const val NOTIFICATION_STATUS_ID = 1002

    const val EXTRA_TARGET_PERCENT = "extra_target_percent"
    const val EXTRA_HOURS = "extra_hours"
    const val EXTRA_MINUTES = "extra_minutes"
    const val EXTRA_ENERGY_KWH = "extra_energy_kwh"
    const val EXTRA_ESTIMATED_COST = "extra_estimated_cost"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Alarm / Complete Channel (High Priority with Sound & Vibration)
            val alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val alarmChannel = NotificationChannel(
                CHANNEL_ALARM_ID,
                "แจ้งเตือนชาร์จแบตเตอรี่เต็ม (Charge Complete)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "ส่งเสียงเตือนและการสั่นเมื่อชาร์จแบตเตอรี่ Yadea GT80 ถึงเป้าหมายที่ตั้งไว้"
                enableLights(true)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
                setSound(alarmSoundUri, audioAttributes)
            }

            // Status / Ongoing Channel (Low Priority, silent progress)
            val statusChannel = NotificationChannel(
                CHANNEL_STATUS_ID,
                "สถานะการชาร์จแบตเตอรี่ (Charging Status)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "แสดงความคืบหน้าระหว่างที่กำลังชาร์จไฟ"
                enableLights(false)
                enableVibration(false)
            }

            notificationManager.createNotificationChannel(alarmChannel)
            notificationManager.createNotificationChannel(statusChannel)
        }
    }

    fun scheduleChargeAlarm(
        context: Context,
        triggerTimeMillis: Long,
        targetPercent: Int,
        hours: Int,
        minutes: Int,
        energyKwh: Float,
        cost: Float
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, ChargeAlarmReceiver::class.java).apply {
            action = ChargeAlarmReceiver.ACTION_CHARGE_COMPLETE
            putExtra(EXTRA_TARGET_PERCENT, targetPercent)
            putExtra(EXTRA_HOURS, hours)
            putExtra(EXTRA_MINUTES, minutes)
            putExtra(EXTRA_ENERGY_KWH, energyKwh)
            putExtra(EXTRA_ESTIMATED_COST, cost)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            NOTIFICATION_ALARM_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTimeMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerTimeMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // Fallback for permission restrictions on some Android versions
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTimeMillis,
                pendingIntent
            )
        }
    }

    fun cancelChargeAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ChargeAlarmReceiver::class.java).apply {
            action = ChargeAlarmReceiver.ACTION_CHARGE_COMPLETE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            NOTIFICATION_ALARM_ID,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(NOTIFICATION_STATUS_ID)
    }

    fun showChargingStatusNotification(
        context: Context,
        currentPercent: Int,
        targetPercent: Int,
        formattedRemaining: String,
        targetTimeFormatted: String
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cancelIntent = Intent(context, ChargeAlarmReceiver::class.java).apply {
            action = ChargeAlarmReceiver.ACTION_CANCEL_CHARGE
        }
        val cancelPendingIntent = PendingIntent.getBroadcast(
            context,
            NOTIFICATION_STATUS_ID,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_STATUS_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⚡ กำลังชาร์จ Yadea GT80 ($currentPercent% ➔ $targetPercent%)")
            .setContentText("เหลือเวลา $formattedRemaining • เสร็จประมาณ $targetTimeFormatted")
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(0, "หยุดชาร์จ", cancelPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_STATUS_ID, notification)
    }

    fun showChargeCompleteNotification(
        context: Context,
        targetPercent: Int,
        hours: Int,
        minutes: Int,
        energyKwh: Float,
        cost: Float
    ) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val timeString = if (hours > 0) "${hours} ชม. ${minutes} นาที" else "${minutes} นาที"

        val costInfo = if (cost > 0) " | ค่าไฟ ~%.1f บาท".format(cost) else ""
        val contentMsg = "แบตเตอรี่ชาร์จถึง $targetPercent% เรียบร้อยแล้ว (ใช้เวลา $timeString$costInfo) กรุณาถอดปลั๊กหรือสั่งตัดไฟ"

        val notification = NotificationCompat.Builder(context, CHANNEL_ALARM_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("⚡ ชาร์จ Yadea GT80 ถึง $targetPercent% แล้ว!")
            .setContentText(contentMsg)
            .setStyle(NotificationCompat.BigTextStyle().bigText(contentMsg))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setSound(alarmSoundUri)
            .setVibrate(longArrayOf(0, 500, 200, 500, 200, 800))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        // Cancel status notification
        notificationManager.cancel(NOTIFICATION_STATUS_ID)
        // Show complete notification
        notificationManager.notify(NOTIFICATION_ALARM_ID, notification)
    }
}
