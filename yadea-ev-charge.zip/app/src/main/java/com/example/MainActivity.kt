package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.components.ActiveChargingCard
import com.example.ui.components.BatterySliderControls
import com.example.ui.components.BatteryVisualizer
import com.example.ui.components.CalculationSummaryCard
import com.example.ui.components.ChargeHistorySheet
import com.example.ui.components.SettingsDialog
import com.example.ui.components.SmartPlugGuideDialog
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricEmerald
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ChargeCalculatorViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ChargeCalculatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                ChargeAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ChargeAppScreen(viewModel: ChargeCalculatorViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showHistorySheet by remember { mutableStateOf(false) }

    // Permission state for Android 13+ (POST_NOTIFICATIONS)
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
        if (isGranted) {
            Toast.makeText(context, "เปิดการแจ้งเตือนเรียบร้อยแล้ว", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle Toast messages
    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToastMessage()
        }
    }

    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(bottom = navBarPadding + 24.dp)
        ) {
            // Header with Hero Banner Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp + statusBarPadding)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.yadea_hero_banner_1789876686732),
                    contentDescription = "Yadea GT80 Electric Motorcycle Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Gradient Overlay for Readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.6f),
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                )

                // Top Navigation Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = statusBarPadding + 8.dp, start = 16.dp, end = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Yadea GT80 Badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .border(1.dp, ElectricCyan.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "YADEA GT80",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = Color.White
                        )
                    }

                    // Top Action Icons (History & Settings)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { showHistorySheet = true },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .testTag("history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "ประวัติการชาร์จ",
                                tint = Color.White
                            )
                        }

                        IconButton(
                            onClick = { viewModel.openSettingsDialog(true) },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "ตั้งค่าสเปก",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Sub-header Model Info at bottom of banner
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp, bottom = 12.dp)
                ) {
                    Text(
                        text = "คำนวณเวลาชาร์จมอเตอร์ไซค์ไฟฟ้า",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "แบตเตอรี่ ${uiState.calculation.batteryCapacityAh.toInt()}Ah • เครื่องชาร์จ ${uiState.calculation.chargerCurrentA.toInt()}A (${uiState.calculation.voltageV.toInt()}V)",
                        style = MaterialTheme.typography.bodySmall,
                        color = ElectricCyan
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Notification Permission Banner (if not granted on Android 13+)
                AnimatedVisibility(visible = !hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = ElectricAmber.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = null,
                                    tint = ElectricAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "เปิดสิทธิ์แจ้งเตือนเพื่อรับเสียงเตือนเมื่อชาร์จเต็ม",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            TextButton(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                }
                            ) {
                                Text("อนุญาต")
                            }
                        }
                    }
                }

                // Active Charging Card (Visible when charging is active)
                AnimatedVisibility(visible = uiState.isChargingActive) {
                    ActiveChargingCard(
                        remainingMillis = uiState.remainingMillis,
                        sessionStartTime = uiState.sessionStartTime,
                        sessionEndTime = uiState.sessionEndTime,
                        currentSimulatedPercent = uiState.currentSimulatedPercent,
                        targetPercent = uiState.calculation.targetPercent,
                        onStopCharging = { viewModel.stopChargingSession(context) },
                        onTestNotification = { viewModel.testAlarmNotification(context) }
                    )
                }

                // Visual Battery Gauge
                BatteryVisualizer(
                    currentPercent = uiState.calculation.currentPercent,
                    targetPercent = uiState.calculation.targetPercent,
                    capacityAh = uiState.calculation.batteryCapacityAh,
                    isCharging = uiState.isChargingActive
                )

                // Battery Slider Controls
                BatterySliderControls(
                    currentPercent = uiState.calculation.currentPercent,
                    targetPercent = uiState.calculation.targetPercent,
                    onCurrentPercentChange = { viewModel.setCurrentPercent(it) },
                    onTargetPercentChange = { viewModel.setTargetPercent(it) },
                    onPresetSelected = { viewModel.applyPresetTarget(it) }
                )

                // Calculation Summary Card
                CalculationSummaryCard(
                    calculation = uiState.calculation,
                    onOpenSmartPlugGuide = { viewModel.openSmartPlugDialog(true) }
                )

                // Primary Charging Action Button
                if (!uiState.isChargingActive) {
                    Button(
                        onClick = {
                            if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            viewModel.startChargingSession(context)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("start_charging_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricCyan,
                            contentColor = Color(0xFF001F29)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "⚡ เริ่มชาร์จ & ตั้งแจ้งเตือนเตือนเต็ม",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                } else {
                    Button(
                        onClick = { viewModel.stopChargingSession(context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("stop_charging_main_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDC2626),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.StopCircle,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "หยุดการชาร์จ / ปิดการแจ้งเตือน",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                // Battery Care Recommendation Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.BatteryChargingFull,
                                contentDescription = null,
                                tint = ElectricEmerald,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "คำแนะนำการถนอมแบตเตอรี่ Yadea GT80",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• ใช้งานประจำวัน: แนะนำชาร์จถึง 80% - 85% ช่วยลดความร้อนและความเครียดของเคมีเซลล์ ทำให้แบตเตอรี่ใช้งานได้ยาวนาน 3-5 ปี\n• เมื่อต้องการเดินทางไกล: ชาร์จถึง 90% - 100%\n• บาลานซ์เซลล์: ควรชาร์จ 100% เดือนละ 1-2 ครั้ง เพื่อให้ BMS เกลี่ยแรงดันเซลล์เท่ากันทุกก้อน\n• ไม่ควรปล่อยให้แบตเตอรี่ต่ำกว่า 15-20% บ่อยๆ",
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    // Dialogs & Sheets
    if (uiState.showSettingsDialog) {
        SettingsDialog(
            calculation = uiState.calculation,
            onSave = { cap, amp, volt, eff, rate ->
                viewModel.updateSpecs(cap, amp, volt, eff, rate)
            },
            onResetDefaults = {
                viewModel.resetToYadeaGt80Default()
            },
            onDismiss = { viewModel.openSettingsDialog(false) }
        )
    }

    if (uiState.showSmartPlugDialog) {
        SmartPlugGuideDialog(
            hours = uiState.calculation.hours,
            minutes = uiState.calculation.minutes,
            onDismiss = { viewModel.openSmartPlugDialog(false) }
        )
    }

    if (showHistorySheet) {
        ChargeHistorySheet(
            historyList = uiState.historyList,
            onClearHistory = { viewModel.clearHistory() },
            onDismiss = { showHistorySheet = false }
        )
    }
}
