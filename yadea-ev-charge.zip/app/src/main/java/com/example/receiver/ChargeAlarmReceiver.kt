package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.notification.NotificationHelper

class ChargeAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_CHARGE_COMPLETE = "com.example.yadea.ACTION_CHARGE_COMPLETE"
        const val ACTION_CANCEL_CHARGE = "com.example.yadea.ACTION_CANCEL_CHARGE"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return

        when (intent.action) {
            ACTION_CHARGE_COMPLETE -> {
                val targetPercent = intent.getIntExtra(NotificationHelper.EXTRA_TARGET_PERCENT, 80)
                val hours = intent.getIntExtra(NotificationHelper.EXTRA_HOURS, 0)
                val minutes = intent.getIntExtra(NotificationHelper.EXTRA_MINUTES, 0)
                val energyKwh = intent.getFloatExtra(NotificationHelper.EXTRA_ENERGY_KWH, 0f)
                val cost = intent.getFloatExtra(NotificationHelper.EXTRA_ESTIMATED_COST, 0f)

                NotificationHelper.showChargeCompleteNotification(
                    context = context,
                    targetPercent = targetPercent,
                    hours = hours,
                    minutes = minutes,
                    energyKwh = energyKwh,
                    cost = cost
                )

                // Update shared preferences to mark charging inactive
                val prefs = context.getSharedPreferences("yadea_charge_prefs", Context.MODE_PRIVATE)
                prefs.edit()
                    .putBoolean("is_charging_active", false)
                    .putBoolean("has_completed_alert", true)
                    .apply()
            }
            ACTION_CANCEL_CHARGE -> {
                NotificationHelper.cancelChargeAlarm(context)
                val prefs = context.getSharedPreferences("yadea_charge_prefs", Context.MODE_PRIVATE)
                prefs.edit()
                    .putBoolean("is_charging_active", false)
                    .apply()
            }
        }
    }
}
